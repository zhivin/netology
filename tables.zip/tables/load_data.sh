#!/bin/bash

psql -c "\copy person FROM '~/person.csv' delimiter '|' null '\N' csv"
psql -c "\copy pie FROM '~/pie.csv' delimiter '|' null '\N' csv"
psql -c "\copy orders FROM '~/orders.csv' delimiter '|' null '\N' csv"
psql -c "\copy order_cart FROM '~/order_cart.csv' delimiter '|' null '\N' csv"
psql -c "\copy order_persons FROM '~/order_persons.csv' delimiter '|' null '\N' csv"
