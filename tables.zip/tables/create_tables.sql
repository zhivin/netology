create table person (
 id serial PRIMARY KEY,
 first_name varchar(50),
 last_name varchar(50),
 birthday date
);

create table pie (
 pie_id serial PRIMARY KEY,
 pie_name varchar(255),
 pie_price float,
 pie_type varchar(50)
);

CREATE TYPE delivery_type AS ENUM ('exp','bar','res');
CREATE TYPE source AS ENUM ('internet','callcenter');

create table orders (
 order_id serial PRIMARY KEY,
 order_date date,
 order_delivery_type delivery_type,
 order_delivery_price float,
 order_source source,
 order_cart_sum float
);

create table order_cart (
 cart_order_id int references orders (order_id),
 cart_pie_id int references pie (pie_id),
 pie_count int,
 pie_kg varchar(5),
 pie_weight varchar(5),
 pie_price float,
 pie_bonus int,
 unique(cart_order_id, cart_pie_id, pie_kg)
)
;

create table order_persons (
 order_id int references orders (order_id),
 person_id int references person (id),
 unique(order_id, person_id)
);
